# AI-Based Cloud File Management System (CSA1705)

Working model of the Review-0 proposal: upload documents, extract text (OCR for images),
embed + auto-tag them, and find files with natural-language **hybrid search**
(semantic similarity + BM25 keyword), behind a login with role-based access.

## Run it
```bash
python -m venv venv && source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
# OCR needs the Tesseract binary:  Windows -> https://github.com/UB-Mannheim/tesseract/wiki
#                                  Ubuntu  -> sudo apt install tesseract-ocr
uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000, register (first user = **admin**), upload the files in `sample_docs/`,
then search e.g. *"money we still owe a supplier"*.

If `sentence-transformers` is not installed the app falls back to a built-in hashed n-gram embedder,
so it still runs; install it for true semantic matching (downloads `all-MiniLM-L6-v2` once).

## Evaluate (precision / recall / response time)
```bash
python evaluate.py
```

## Mapping to the slides
| Slide block | Owner | File |
|---|---|---|
| Upload, cloud storage (local folder or AWS S3), login, RBAC | M1 Krishna | `app/storage.py`, `app/security.py`, `app/main.py` |
| Text extraction + OCR | M1/M2 | `app/extract.py` |
| Cleaning, chunking, embeddings, auto-tags | M2 Sanjay | `app/nlp.py` |
| Vector index (FAISS/NumPy) + metadata DB | M2 | `app/index.py`, `app/db.py` |
| Query embedding, hybrid match, ranking, UI, evaluation | M3 Santhosh | `app/index.py`, `static/index.html`, `evaluate.py` |

## Configuration (env vars)
`STORAGE_BACKEND=s3` + `S3_BUCKET=...` (uses AWS credentials, SSE-AES256) · `APP_SECRET` (token signing key) ·
`HYBRID_ALPHA` (semantic weight, default 0.65) · `EMBED_MODEL`.

## API
`POST /api/register|login` · `POST /api/upload` · `GET /api/files` · `GET /api/search?q=&mode=hybrid|semantic|keyword`
· `GET /api/files/{id}/preview|download` · `DELETE /api/files/{id}` · `GET /api/stats`

## Notes / limits
Scanned (image-only) PDFs are not OCR'd; images are. UI is plain HTML/JS (the slides list React) to avoid a build step.
Auth tokens are HMAC-signed; set `APP_SECRET` and serve over HTTPS for any real deployment.
