"""FastAPI app: wires Module 1 (ingest/security), Module 2 (AI indexing), Module 3 (search/UI)."""
import io, time
from pathlib import Path
from fastapi import Depends, FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import db
from .config import ALLOWED, BASE
from .extract import extract_text
from .index import index
from .nlp import auto_tag, chunk, clean, embedder
from .security import current_user, hash_password, make_token, verify_password
from .storage import store

app = FastAPI(title="AI Cloud File Management System")
db.init()
index.load(db.all("SELECT id, file_id, text FROM chunks ORDER BY id"))


class Cred(BaseModel):
    username: str
    password: str


# ---------------------------------------------------------------- auth (M1)
@app.post("/api/register")
def register(c: Cred):
    if len(c.username) < 3 or len(c.password) < 6:
        raise HTTPException(400, "Username >= 3 chars, password >= 6 chars")
    if db.one("SELECT id FROM users WHERE username=?", (c.username,)):
        raise HTTPException(409, "Username already taken")
    role = "admin" if not db.one("SELECT id FROM users LIMIT 1") else "user"   # first user = admin
    uid = db.run("INSERT INTO users(username,password,role) VALUES(?,?,?)",
                 (c.username, hash_password(c.password), role))
    return {"token": make_token(uid, role), "username": c.username, "role": role}


@app.post("/api/login")
def login(c: Cred):
    u = db.one("SELECT * FROM users WHERE username=?", (c.username,))
    if not u or not verify_password(c.password, u["password"]):
        raise HTTPException(401, "Wrong username or password")
    return {"token": make_token(u["id"], u["role"]), "username": u["username"], "role": u["role"]}


def visible_files(user: dict) -> list[dict]:
    """Role-based access: admin sees everything, users see only their own files."""
    if user["role"] == "admin":
        return db.all("SELECT f.*, u.username AS owner FROM files f JOIN users u ON u.id=f.owner_id ORDER BY uploaded DESC")
    return db.all("SELECT f.*, u.username AS owner FROM files f JOIN users u ON u.id=f.owner_id "
                  "WHERE owner_id=? ORDER BY uploaded DESC", (user["id"],))


def get_file(file_id: int, user: dict) -> dict:
    f = db.one("SELECT * FROM files WHERE id=?", (file_id,))
    if not f:
        raise HTTPException(404, "File not found")
    if user["role"] != "admin" and f["owner_id"] != user["id"]:
        raise HTTPException(403, "Not your file")
    return f


# ----------------------------------------------- upload + indexing (M1 -> M2)
def ingest(name: str, data: bytes, user: dict) -> dict:
    ext = Path(name).suffix.lower()
    if ext not in ALLOWED:
        raise HTTPException(400, f"Unsupported type {ext}. Allowed: {', '.join(sorted(ALLOWED))}")
    text = clean(extract_text(name, data))                    # parsers + OCR
    if not text:
        raise HTTPException(422, "No text could be extracted from this file")
    category, tags = auto_tag(text)                            # NLP auto-tagging
    key = store.put(name, data)                                # cloud storage
    fid = db.run("INSERT INTO files(owner_id,name,key,ext,size,category,tags,uploaded) VALUES(?,?,?,?,?,?,?,?)",
                 (user["id"], name, key, ext, len(data), category, ", ".join(tags), time.time()))
    rows = []
    for i, ch in enumerate(chunk(text)):                       # chunking
        cid = db.run("INSERT INTO chunks(file_id,idx,text) VALUES(?,?,?)", (fid, i, ch))
        rows.append({"id": cid, "file_id": fid, "text": ch})
    index.add(rows)                                            # embeddings -> vector index
    return {"id": fid, "name": name, "category": category, "tags": tags, "chunks": len(rows)}


@app.post("/api/upload")
async def upload(files: list[UploadFile] = File(...), user: dict = Depends(current_user)):
    results = []
    for f in files:
        try:
            results.append(ingest(f.filename, await f.read(), user))
        except HTTPException as e:
            results.append({"name": f.filename, "error": e.detail})
    return results


@app.get("/api/files")
def list_files(user: dict = Depends(current_user)):
    return visible_files(user)


@app.delete("/api/files/{file_id}")
def delete_file(file_id: int, user: dict = Depends(current_user)):
    f = get_file(file_id, user)
    store.delete(f["key"])
    db.run("DELETE FROM chunks WHERE file_id=?", (file_id,))
    db.run("DELETE FROM files WHERE id=?", (file_id,))
    index.remove_file(file_id)
    return {"deleted": file_id}


@app.get("/api/files/{file_id}/download")
def download(file_id: int, user: dict = Depends(current_user)):
    f = get_file(file_id, user)
    return StreamingResponse(io.BytesIO(store.get(f["key"])), media_type="application/octet-stream",
                             headers={"Content-Disposition": f'attachment; filename="{f["name"]}"'})


@app.get("/api/files/{file_id}/preview")
def preview(file_id: int, user: dict = Depends(current_user)):
    f = get_file(file_id, user)
    chunks = db.all("SELECT text FROM chunks WHERE file_id=? ORDER BY idx", (file_id,))
    return {"name": f["name"], "category": f["category"], "tags": f["tags"],
            "text": " ".join(c["text"] for c in chunks)[:4000]}


# ------------------------------------------------------------- search (M3)
@app.get("/api/search")
def search(q: str, mode: str = "hybrid", k: int = 10, user: dict = Depends(current_user)):
    if not q.strip():
        raise HTTPException(400, "Empty query")
    t0 = time.perf_counter()
    allowed = None if user["role"] == "admin" else {f["id"] for f in visible_files(user)}
    hits = index.search(q, allowed, top_k=k, mode=mode)
    ms = round((time.perf_counter() - t0) * 1000, 1)
    meta = {f["id"]: f for f in visible_files(user)}
    for h in hits:
        f = meta[h["file_id"]]
        h.update(name=f["name"], category=f["category"], tags=f["tags"], ext=f["ext"], owner=f["owner"])
    return {"query": q, "mode": mode, "time_ms": ms, "embedder": embedder.kind, "results": hits}


@app.get("/api/stats")
def stats(user: dict = Depends(current_user)):
    return {"files": len(visible_files(user)), "chunks": len(index.ids), "embedder": embedder.kind,
            "faiss": index.faiss is not None}


app.mount("/", StaticFiles(directory=BASE / "static", html=True), name="static")
