"""Module 1 - authentication, role-based access, signed tokens (stdlib only)."""
import base64, hashlib, hmac, json, os, time
from fastapi import Depends, HTTPException, Header
from .config import SECRET, TOKEN_TTL
from . import db


def hash_password(pw: str, salt: bytes | None = None) -> str:
    salt = salt or os.urandom(16)
    h = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, 120_000)
    return salt.hex() + "$" + h.hex()


def verify_password(pw: str, stored: str) -> bool:
    salt_hex, _ = stored.split("$")
    return hmac.compare_digest(hash_password(pw, bytes.fromhex(salt_hex)), stored)


def _sign(payload: bytes) -> str:
    return hmac.new(SECRET.encode(), payload, hashlib.sha256).hexdigest()


def make_token(user_id: int, role: str) -> str:
    body = base64.urlsafe_b64encode(json.dumps(
        {"uid": user_id, "role": role, "exp": time.time() + TOKEN_TTL}).encode())
    return body.decode() + "." + _sign(body)


def current_user(authorization: str = Header(default="")) -> dict:
    try:
        body, sig = authorization.replace("Bearer ", "").split(".")
        if not hmac.compare_digest(sig, _sign(body.encode())):
            raise ValueError
        data = json.loads(base64.urlsafe_b64decode(body))
        if data["exp"] < time.time():
            raise ValueError
    except Exception:
        raise HTTPException(401, "Invalid or expired token")
    user = db.one("SELECT id, username, role FROM users WHERE id=?", (data["uid"],))
    if not user:
        raise HTTPException(401, "Unknown user")
    return user
