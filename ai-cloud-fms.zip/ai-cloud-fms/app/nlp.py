"""Module 2 - cleaning, chunking, embeddings and auto-tagging."""
import hashlib, math, re
from collections import Counter
import numpy as np
from .config import EMBED_MODEL, CHUNK_WORDS, CHUNK_OVERLAP

STOP = set("""a an the and or but if of to in on at by for with from as is are was were be been it this
that these those which who whom whose will would can could should may might not no yes we you they he she
i our their its into than then so such also about over under more most other some any each per via has have
had do does did there here what when where how all""".split())

TOKEN = re.compile(r"[a-z0-9]+")


def clean(text: str) -> str:
    return re.sub(r"\s+", " ", text.replace("\x00", " ")).strip()


def tokens(text: str) -> list[str]:
    return [t for t in TOKEN.findall(text.lower()) if t not in STOP and len(t) > 1]


def chunk(text: str) -> list[str]:
    words = text.split()
    if not words:
        return []
    step = CHUNK_WORDS - CHUNK_OVERLAP
    return [" ".join(words[i:i + CHUNK_WORDS])
            for i in range(0, max(len(words) - CHUNK_OVERLAP, 1), step)]


class Embedder:
    """Sentence-Transformers if installed (true semantic search); otherwise a
    dependency-free hashed word + char-trigram embedding so the system still runs."""
    def __init__(self):
        self.model, self.dim, self.kind = None, 384, "hashed-ngram (fallback)"
        try:
            from sentence_transformers import SentenceTransformer
            self.model = SentenceTransformer(EMBED_MODEL)
            self.dim = self.model.get_sentence_embedding_dimension()
            self.kind = EMBED_MODEL
        except Exception as e:
            print(f"[embedder] sentence-transformers unavailable ({type(e).__name__}); using fallback")

    def _hash_vec(self, text: str) -> np.ndarray:
        v = np.zeros(self.dim, dtype="float32")
        for w in tokens(text):
            for g in [w] + [w[i:i + 3] for i in range(len(w) - 2)]:
                h = int(hashlib.md5(g.encode()).hexdigest(), 16)
                v[h % self.dim] += (1.0 if g == w else 0.4) * (1 if (h >> 20) & 1 else -1)
        n = np.linalg.norm(v)
        return v / n if n else v

    def encode(self, texts: list[str]) -> np.ndarray:
        if self.model is not None:
            return np.asarray(self.model.encode(texts, normalize_embeddings=True,
                                                show_progress_bar=False), dtype="float32")
        if not texts:
            return np.zeros((0, self.dim), "float32")
        return np.vstack([self._hash_vec(t) for t in texts])


embedder = Embedder()

CATEGORIES = {
    "Finance":   "invoice payment budget revenue tax account bank cost expense profit audit salary",
    "Legal":     "contract agreement clause liability law court policy compliance terms legal",
    "Technical": "software system server code algorithm network database api cloud model data",
    "Academic":  "research study thesis university course student paper experiment learning",
    "HR":        "employee hiring recruitment leave resume candidate interview training onboarding",
    "Medical":   "patient doctor hospital medicine treatment diagnosis clinical health disease",
    "Business":  "marketing customer sales strategy market meeting project plan report client",
}


def auto_tag(text: str, k: int = 5) -> tuple[str, list[str]]:
    toks = tokens(text)
    if not toks:
        return "General", []
    counts = Counter(toks)
    keywords = [w for w, _ in counts.most_common(40) if not w.isdigit() and len(w) > 3][:k]
    best, best_score = "General", 0.0
    for cat, vocab in CATEGORIES.items():
        score = sum(counts[w] for w in vocab.split()) / math.sqrt(len(toks))
        if score > best_score:
            best, best_score = cat, score
    return (best if best_score >= 0.5 else "General"), keywords
