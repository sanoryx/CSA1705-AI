"""Module 2/3 - vector index (FAISS or NumPy) + BM25 keyword index + hybrid ranking."""
import math
from collections import Counter
import numpy as np
from .config import VEC_PATH, ALPHA
from .nlp import embedder, tokens

try:
    import faiss
except Exception:
    faiss = None


class HybridIndex:
    def __init__(self):
        self.ids: list[int] = []          # chunk ids, aligned with rows
        self.file_ids: list[int] = []
        self.texts: list[str] = []
        self.mat = np.zeros((0, embedder.dim), "float32")
        self.toks: list[list[str]] = []
        self.df: Counter = Counter()
        self.avgdl = 1.0
        self.faiss = None

    # ---------- persistence / build
    def load(self, rows: list[dict]):
        """rows: chunks from SQLite. Reuses saved vectors when they still match."""
        self.ids = [r["id"] for r in rows]
        self.file_ids = [r["file_id"] for r in rows]
        self.texts = [r["text"] for r in rows]
        saved = {}
        if VEC_PATH.exists():
            try:
                z = np.load(VEC_PATH, allow_pickle=False)
                if z["mat"].shape[1] == embedder.dim:
                    saved = dict(zip(z["ids"].tolist(), z["mat"]))
            except Exception:
                saved = {}
        missing = [i for i, cid in enumerate(self.ids) if cid not in saved]
        if missing:
            enc = embedder.encode([self.texts[i] for i in missing])
            for i, v in zip(missing, enc):
                saved[self.ids[i]] = v
        self.mat = (np.vstack([saved[c] for c in self.ids]).astype("float32")
                    if self.ids else np.zeros((0, embedder.dim), "float32"))
        self._rebuild()
        self.save()

    def save(self):
        np.savez(VEC_PATH.with_suffix(""), ids=np.array(self.ids, dtype="int64"), mat=self.mat)

    def _rebuild(self):
        self.toks = [tokens(t) for t in self.texts]
        self.df = Counter(w for t in self.toks for w in set(t))
        self.avgdl = (sum(map(len, self.toks)) / len(self.toks)) if self.toks else 1.0
        if faiss is not None and len(self.mat):
            self.faiss = faiss.IndexFlatIP(self.mat.shape[1])
            self.faiss.add(self.mat)
        else:
            self.faiss = None

    def add(self, chunk_rows: list[dict]):
        self.load_append(chunk_rows)

    def load_append(self, rows):
        enc = embedder.encode([r["text"] for r in rows])
        self.ids += [r["id"] for r in rows]
        self.file_ids += [r["file_id"] for r in rows]
        self.texts += [r["text"] for r in rows]
        self.mat = np.vstack([self.mat, enc]) if len(self.mat) else enc
        self._rebuild()
        self.save()

    def remove_file(self, file_id: int):
        keep = [i for i, f in enumerate(self.file_ids) if f != file_id]
        self.ids = [self.ids[i] for i in keep]
        self.file_ids = [self.file_ids[i] for i in keep]
        self.texts = [self.texts[i] for i in keep]
        self.mat = self.mat[keep] if keep else np.zeros((0, embedder.dim), "float32")
        self._rebuild()
        self.save()

    # ---------- scoring
    def _bm25(self, q_toks: list[str], k1=1.5, b=0.75) -> np.ndarray:
        n = len(self.toks)
        scores = np.zeros(n, "float32")
        for w in set(q_toks):
            df = self.df.get(w, 0)
            if not df:
                continue
            idf = math.log(1 + (n - df + 0.5) / (df + 0.5))
            for i, t in enumerate(self.toks):
                tf = t.count(w)
                if tf:
                    scores[i] += idf * tf * (k1 + 1) / (tf + k1 * (1 - b + b * len(t) / self.avgdl))
        return scores

    def search(self, query: str, allowed_files: set[int] | None, top_k=10, alpha=ALPHA, mode="hybrid"):
        if not self.ids:
            return []
        q = embedder.encode([query])[0]
        sem = (self.mat @ q).astype("float32")                     # cosine (unit vectors)
        sem_n = np.clip(sem, 0, None)
        if sem_n.max() > 0:
            sem_n = sem_n / sem_n.max()
        kw = self._bm25(tokens(query))
        kw_n = kw / kw.max() if kw.max() > 0 else kw
        if mode == "semantic":
            final = sem_n
        elif mode == "keyword":
            final = kw_n
        else:
            final = alpha * sem_n + (1 - alpha) * kw_n

        best: dict[int, tuple[float, int]] = {}
        for i in np.argsort(-final)[: max(top_k * 6, 30)]:
            fid = self.file_ids[i]
            if allowed_files is not None and fid not in allowed_files:
                continue
            if final[i] <= 0:
                continue
            if fid not in best or final[i] > best[fid][0]:
                best[fid] = (float(final[i]), int(i))
        out = []
        for fid, (score, i) in sorted(best.items(), key=lambda x: -x[1][0])[:top_k]:
            out.append({"file_id": fid, "score": round(score, 4),
                        "semantic": round(float(sem[i]), 4), "keyword": round(float(kw_n[i]), 4),
                        "snippet": self.texts[i][:280]})
        return out


index = HybridIndex()
