import sqlite3
from .config import DB_PATH


def conn():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c


def init():
    with conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT, role TEXT);
        CREATE TABLE IF NOT EXISTS files(
            id INTEGER PRIMARY KEY, owner_id INTEGER, name TEXT, key TEXT,
            ext TEXT, size INTEGER, category TEXT, tags TEXT, uploaded REAL);
        CREATE TABLE IF NOT EXISTS chunks(
            id INTEGER PRIMARY KEY, file_id INTEGER, idx INTEGER, text TEXT);
        """)


def one(q, a=()):
    with conn() as c:
        r = c.execute(q, a).fetchone()
        return dict(r) if r else None


def all(q, a=()):
    with conn() as c:
        return [dict(r) for r in c.execute(q, a).fetchall()]


def run(q, a=()):
    with conn() as c:
        return c.execute(q, a).lastrowid
