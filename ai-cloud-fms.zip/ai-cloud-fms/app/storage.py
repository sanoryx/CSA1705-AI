"""Module 1 - cloud storage abstraction. Local folder by default, AWS S3 optional."""
import uuid
from pathlib import Path
from .config import DATA, STORAGE_BACKEND, S3_BUCKET

_LOCAL = DATA / "bucket"
_LOCAL.mkdir(exist_ok=True)


class LocalStorage:
    def put(self, name: str, data: bytes) -> str:
        key = f"{uuid.uuid4().hex}_{Path(name).name}"
        (_LOCAL / key).write_bytes(data)
        return key

    def get(self, key: str) -> bytes:
        return (_LOCAL / key).read_bytes()

    def delete(self, key: str):
        (_LOCAL / key).unlink(missing_ok=True)


class S3Storage:
    def __init__(self):
        import boto3
        self.s3, self.bucket = boto3.client("s3"), S3_BUCKET

    def put(self, name, data):
        key = f"{uuid.uuid4().hex}_{Path(name).name}"
        self.s3.put_object(Bucket=self.bucket, Key=key, Body=data,
                           ServerSideEncryption="AES256")
        return key

    def get(self, key):
        return self.s3.get_object(Bucket=self.bucket, Key=key)["Body"].read()

    def delete(self, key):
        self.s3.delete_object(Bucket=self.bucket, Key=key)


store = S3Storage() if STORAGE_BACKEND == "s3" else LocalStorage()
