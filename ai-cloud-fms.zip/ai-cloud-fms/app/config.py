import os
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
DATA = Path(os.getenv("APP_DATA", BASE / "data"))
DATA.mkdir(exist_ok=True)

DB_PATH = DATA / "app.db"
VEC_PATH = DATA / "vectors.npy"
SECRET = os.getenv("APP_SECRET", "change-me-in-production")
TOKEN_TTL = 60 * 60 * 8
STORAGE_BACKEND = os.getenv("STORAGE_BACKEND", "local")   # local | s3
S3_BUCKET = os.getenv("S3_BUCKET", "")
EMBED_MODEL = os.getenv("EMBED_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
ALPHA = float(os.getenv("HYBRID_ALPHA", "0.65"))          # weight of semantic score
CHUNK_WORDS, CHUNK_OVERLAP = 120, 25
ALLOWED = {".pdf", ".docx", ".txt", ".png", ".jpg", ".jpeg"}
