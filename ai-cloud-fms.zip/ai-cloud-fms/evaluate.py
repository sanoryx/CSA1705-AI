"""Evaluation: precision@k, recall@k and response time for keyword vs semantic vs hybrid search.
Runs on an isolated temp database using the files in sample_docs/."""
import os, tempfile, statistics
os.environ["APP_DATA"] = tempfile.mkdtemp()

from fastapi.testclient import TestClient
from app.main import app

# natural-language query -> set of relevant sample files (ground truth)
GROUND_TRUTH = {
    "money we still owe a supplier":              {"invoice_acme.txt"},
    "how much will the company earn and spend next year": {"budget_2026.txt"},
    "rules about quitting a job and keeping secrets":     {"employment_contract.txt"},
    "how to design servers that scale":           {"cloud_architecture.txt"},
    "neural network language model experiments":  {"ml_research.txt"},
    "how to recruit and train new staff":         {"hiring_policy.txt"},
    "sick person treatment at hospital":          {"patient_report.txt"},
    "advertising campaign for selling our product": {"marketing_plan.txt"},
    "deadline for final year student project":    {"campus_notice.txt"},
    "weak passwords and unsafe network":          {"security_audit.txt"},
}
K = 3

c = TestClient(app)
tok = c.post("/api/register", json={"username": "evaluator", "password": "secret123"}).json()["token"]
H = {"Authorization": f"Bearer {tok}"}
for fn in sorted(os.listdir("sample_docs")):
    with open(f"sample_docs/{fn}", "rb") as fh:
        c.post("/api/upload", files={"files": (fn, fh.read())}, headers=H)

print(f"Embedder: {c.get('/api/stats', headers=H).json()['embedder']}\n")
print(f"{'mode':10} {'P@%d'%K:>6} {'R@%d'%K:>6} {'MRR':>6} {'avg ms':>8}")
for mode in ("keyword", "semantic", "hybrid"):
    P, R, RR, T = [], [], [], []
    for q, rel in GROUND_TRUTH.items():
        r = c.get("/api/search", params={"q": q, "mode": mode, "k": K}, headers=H).json()
        names = [x["name"] for x in r["results"]]
        hit = [n for n in names if n in rel]
        P.append(len(hit) / K)
        R.append(len(hit) / len(rel))
        RR.append(next((1 / (i + 1) for i, n in enumerate(names) if n in rel), 0))
        T.append(r["time_ms"])
    print(f"{mode:10} {statistics.mean(P):6.2f} {statistics.mean(R):6.2f} {statistics.mean(RR):6.2f} {statistics.mean(T):8.1f}")
